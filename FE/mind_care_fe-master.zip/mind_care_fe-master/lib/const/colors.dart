import 'package:flutter/material.dart';

const PRIMARY_COLOR = Colors.blueAccent;
final LIGHT_GREY_COLOR = Colors.grey[150]!;
final DARK_GREY_COLOR = Colors.grey[600]!;
final TEXT_FIELD_FILL_COLOR = Colors.grey[300]!;