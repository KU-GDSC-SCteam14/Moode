import 'package:mind_care/screen/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:mind_care/page/write_diary_pg1.dart';
import 'package:mind_care/page/write_diary_pg2.dart';
import 'package:mind_care/page/write_diary_pg3.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:mind_care/db.dart';
import 'package:intl/intl.dart';
import 'package:timer_builder/timer_builder.dart';
//import 'dart:convert';
//import 'package:http/http.dart' as http;

final titleController = TextEditingController();
var now = DateTime.now();
final String date = DateFormat('h:mm, MMM d, yyy').format(now);

Future<void> modifyDiary(BuildContext context) async {
  //final int diaryId = ; // 수정할 일기의 ID
  final prefs = await SharedPreferences.getInstance();
  final userid = prefs.getInt('userid'); // SharedPreferences에서 userid 불러오기

  if (userid != null) {
    // 사용자로부터 수정된 일기 데이터
    Map<String, dynamic> updatedDiaryData = {
      //'User_ID': userid, // SharedPreferences에서 불러온 userid 사용
      'Title': titleController.text,
      //'Content_1': experienceTextController.text,
      //'Content_2': emotionTextController.text,
      //'Content_3': reasonTextController.text,
      //'Content_4': thinkTextController.text,
      'Date': date, // 09:00, Mar 16, 2024
    };
    // 데이터베이스에서 일기 데이터 업데이트
    await DatabaseService.updateDiary(diaryId, updatedDiaryData);
    print('Diary with ID: $diaryId has been updated');
  } else {
    print('User ID not found in SharedPreferences.');
  }
  Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => const HomeScreen()),
  );
}

class Result extends StatefulWidget {
  const Result({super.key});

  @override
  State<Result> createState() => _Result();
}

class _Result extends State<Result> {
  // Future<void> uploadDiaryToServer() async {
  //   final String apiUrl = "http://34.64.58.86:3000/Diary";

  //   // 사용자 데이터를 Map 형식으로 정의
  //   Map<String, dynamic> userData = {
  //     'Title': titleController.text,
  //     'Date': date,
  //   };

  //   // Map을 JSON 문자열로 변환
  //   String jsonData = jsonEncode(userData);

  //   try {
  //     // HTTP POST 요청 보내기
  //     final response = await http.post(
  //       Uri.parse(apiUrl),
  //       headers: {'Content-Type': 'application/json'},
  //       body: jsonData,
  //     );

  //     if (response.statusCode == 200) {
  //       print('User created successfully.');
  //     } else {
  //       print('Error creating user. Status code: ${response.statusCode}');
  //       print('Response body: ${response.body}');
  //     }
  //   } catch (e) {
  //     print('Exception: $e');
  //   }
  // }

  void onPressedHandler() {
    //uploadDiaryToServer();
    modifyDiary(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            const Text('작성완료', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(moodName,
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            TextField(
              controller: titleController,
              decoration: const InputDecoration(labelText: '제목을 입력하세요.'),
            ),
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                color: const Color(0xfffbfbfb),
              ),
              alignment: Alignment.centerLeft,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // 아래
                    child: Row(
                      children: [
                        Container(
                            // 키워드
                            child: Row(
                          children: [
                            Text(keywords[0]),
                          ],
                        )),
                      ],
                    ),
                  ),
                  const Text(
                    '오늘 어떤 일이 있었나요?',
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Color(0xffABB0BC),
                    ),
                  ),
                  Container(
                    height: 20,
                  ),
                  Text(
                    experienceTextController.text,
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  Container(
                    height: 20,
                  ),
                  const Text(
                    '그때의 감정을 자세히 들려주세요.',
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Color(0xffABB0BC),
                    ),
                  ),
                  Container(
                    height: 20,
                  ),
                  Text(
                    emotionTextController.text,
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  Container(
                    height: 20,
                  ),
                  const Text(
                    '왜 그런 감정이 든 것 같나요?',
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Color(0xffABB0BC),
                    ),
                  ),
                  Container(
                    height: 20,
                  ),
                  Text(
                    reasonTextController.text,
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  Container(
                    height: 20,
                  ),
                  const Text(
                    '나에게 해주고 싶은 말을 자유롭게 적어주세요.',
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Color(0xffABB0BC),
                    ),
                  ),
                  Container(
                    height: 20,
                  ),
                  Text(
                    thinkTextController.text,
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ),
            ElevatedButton(
              onPressed: () {
                modifyDiary(context);
                Navigator.popUntil(context, ModalRoute.withName('/'));
              },
              style: ElevatedButton.styleFrom(
                  backgroundColor: Theme.of(context).primaryColor),
              child: const Text('메인 화면으로'),
            ),
          ],
        ),
      ),
    );
  }
}
