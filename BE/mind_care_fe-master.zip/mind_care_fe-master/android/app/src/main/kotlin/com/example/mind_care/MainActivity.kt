package com.example.mind_care

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
